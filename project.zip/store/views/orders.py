from django.views import View
from django.shortcuts import render,redirect
from store.models.product import Product
from store.models.orders import Orders
from store.models.customer import Customer
class PlaceOrder(View):
    def get(self,request):
        customer=request.session.get('customer_id')
        pro=Orders.get_order_by_id(customer)
        return render(request,'ordersplace.html',{'pro':pro})


