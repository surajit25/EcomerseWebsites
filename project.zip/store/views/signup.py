from django.contrib.auth.hashers import make_password
from django.shortcuts import render,redirect
from store.models import Customer
from django.views import View

class SignUp(View):
    def get(self,request):
        return render(request, 'signup.html')


    def post(self,request):
        pre = request.POST
        firstname = pre.get('firstname')
        lastname = pre.get('lastname')
        email = pre.get('email')
        phone = pre.get('phone')
        username = pre.get('username')
        password = pre.get('password')
        cpassword = pre.get('cpassword')
        savepassword = make_password(password)
        customer = Customer(first_name=firstname, last_name=lastname, email=email, phone=phone, user_name=username,
                            password=savepassword)
        error_message = None
        success_message = None
        data = {
            'first_name': firstname,
            'last_name': lastname,
            'email': email,
            'phone': phone,
            'username': username
        }
        if not firstname:
            error_message = "first name required"
            dic = {
                'error': error_message,
                'values': data
            }
            return render(request, 'signup.html', dic)
        elif not lastname:
            error_message = "last name required"

            dic = {
                'error': error_message,
                'values': data
            }
            return render(request, 'signup.html', dic)
        elif not email:
            error_message = "Email is required"

            dic = {
                'error': error_message,
                'values': data
            }
            return render(request, 'signup.html', dic)
        elif Customer.objects.filter(email=email):
            error_message = "Email is already registered"
            dic = {
                'error': error_message,
                'values': data
            }
            return render(request, 'signup.html', dic)


        elif not phone:
            error_message = "phone number is required"

            dic = {
                'error': error_message,
                'values': data
            }
            return render(request, 'signup.html', dic)
        elif len(phone) < 10 or len(phone) > 10:
            error_message = "Phone number should be 10 digit"

            dic = {
                'error': error_message,
                'values': data
            }
            return render(request, 'signup.html', dic)
        elif not username:
            error_message = "Username is required"

            dic = {
                'error': error_message,
                'values': data
            }
            return render(request, 'signup.html', dic)
        elif password != cpassword:
            error_message = "Password and confirm password not same"

            dic = {
                'error': error_message,
                'values': data
            }
            return render(request, 'signup.html', dic)
        elif len(password) < 8:
            error_message = "password length should not less than 8 character";
            return render(request, 'signup.html', {'error': error_message})
        else:
            customer.save()
            return redirect('homepage')