from django.views import View
from django.shortcuts import render,redirect
from store.models.product import Product
from store.models.orders import Orders
from store.models.customer import Customer
class Checkout(View):
    def get(self,request):
        pass;
    def post(self,request):
        address=request.POST.get('address')
        phone=request.POST.get('phone')
        customervalue=request.session['customer_id']
        print(customervalue)

        cart=request.session.get('cart')
        key=list(cart.keys())

        pro=Product.find_product_by_id(key)

        for x in pro:
            order=Orders(
                product=x,
                customer=Customer(id=customervalue),
                address=address,
                phone=phone,
                price=x.price,
                quantity=cart.get(str(x.id))
            )
            order.save()
        request.session['cart']={}
        return redirect('cart')

