from django.contrib import admin
from .models import Product
from .models import Category
from .models import Customer
from .models import Orders
# Register your models here.

class AdminProduct(admin.ModelAdmin):
    list_display = ['name','price','category']

class AdminCategory(admin.ModelAdmin):
    list_display = ['name']

class AdminCustomer(admin.ModelAdmin):
    list_display = ['user_name','email']

class AdminOrder(admin.ModelAdmin):
    list_display = ['product','customer','price','quantity','date','address','status']

admin.site.register(Product ,AdminProduct)
admin.site.register(Category, AdminCategory)
admin.site.register(Customer,AdminCustomer)
admin.site.register(Orders,AdminOrder)


