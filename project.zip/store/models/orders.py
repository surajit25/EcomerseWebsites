from django.db import models
from .product import Product
from .customer import Customer
import datetime


class Orders(models.Model):
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    customer=models.ForeignKey(Customer,on_delete=models.CASCADE)
    quantity=models.IntegerField(default='')
    price =models.IntegerField(default='')
    address=models.TextField(default='',max_length=100)
    phone=models.CharField(default='',max_length=10)
    status=models.BooleanField(default=False)
    date = models.DateTimeField(default=datetime.datetime.today)

    @staticmethod
    def get_order_by_id(id):
        return Orders\
            .objects\
            .filter(customer=id).\
            order_by('-date')

